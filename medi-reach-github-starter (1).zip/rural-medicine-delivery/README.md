# MediReach – Rural Medicine Delivery Platform

## 1. Project Overview
MediReach is a rural-focused medicine e-commerce platform designed to help elderly people obtain medicines conveniently and on time. It connects elderly customers with nearby medical shops and local delivery partners.

## 2. Problem Statement
Elderly people in rural areas may face difficulty travelling to medical shops because of distance, limited transportation, mobility challenges, and lack of convenient digital services. This can result in delays in obtaining medicines.

## 3. Proposed Solution
MediReach allows users to:
- Search for medicines
- Find nearby participating medical shops
- Upload prescriptions when required
- Place medicine orders
- Select a delivery option
- Track order status
- Allow a caregiver/family member to place an order remotely

Medical shops can manage medicine stock and process orders, while delivery partners can update pickup and delivery status.

## 4. Main Users
- Elderly Customer
- Family/Caregiver
- Medical Shop
- Delivery Partner
- Administrator

## 5. Key Features
- Elderly-friendly user interface
- Medicine search and product details
- Nearby medical-shop selection
- Prescription upload
- Cart and order management
- Order status tracking
- Caregiver-assisted ordering
- Medical-shop inventory management
- Delivery-partner workflow
- Admin management

## 6. Technology
Suggested implementation:
- Frontend: HTML, CSS, JavaScript / React
- Backend: Node.js, Express.js
- Database: MongoDB
- Authentication: JWT
- Maps/location: Google Maps or OpenStreetMap-based service
- Version control: Git and GitHub

Replace this section with the exact technologies used in the final prototype.

## 7. System Flow
Elderly User/Caregiver
        |
        v
MediReach Web Application
        |
        +----> Medicine Database
        |
        +----> Nearby Medical Shops
        |
        +----> Order Management
                    |
                    v
             Medical Shop
                    |
                    v
             Delivery Partner
                    |
                    v
             Elderly Customer

## 8. Setup

### Prerequisites
- Git
- Node.js and npm
- MongoDB (local or cloud)
- Modern web browser

### Clone
```bash
git clone https://github.com/YOUR_USERNAME/rural-medicine-delivery.git
cd rural-medicine-delivery
```

### Backend
```bash
cd backend
npm install
```

Create a `.env` file:
```env
PORT=5000
MONGODB_URI=your_mongodb_connection_string
JWT_SECRET=your_secret_key
```

Start the backend:
```bash
npm run dev
```

### Frontend
Open a second terminal:
```bash
cd frontend
```

Run the frontend using the command required by your implementation (for example, `npm install` and `npm run dev` for a React/Vite project).

## 9. Sample Data
Sample medicine and medical-shop data are available in `sample-data/`.

## 10. Testing
Basic functional test cases are available in `tests/test-cases.md`.

## 11. Technical Design
See `docs/technical-design.md`.

## 12. Healthcare and Safety
MediReach is an ordering and delivery platform, not a diagnosis or prescription-generation system. Prescription medicines should be fulfilled only after appropriate verification by the medical/pharmacy provider and in accordance with applicable laws and regulations. No real patient data should be included in the public repository.

## 13. UNSDG Alignment
- SDG 3 – Good Health and Well-being: improves timely access to medicines.
- SDG 10 – Reduced Inequalities: helps reduce healthcare accessibility gaps for rural elderly users.
- SDG 9 – Industry, Innovation and Infrastructure: applies digital technology to improve rural healthcare access.

## 14. Future Enhancements
- Tamil and other regional-language support
- Voice-assisted medicine search
- SMS/WhatsApp notifications
- Medicine refill reminders
- Caregiver dashboard
- Route optimization for delivery
- Low-bandwidth/offline-friendly experience

## 15. License
This project is released under the MIT License. See `LICENSE`.
