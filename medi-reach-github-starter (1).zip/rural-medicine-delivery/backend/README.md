# Backend

Place the MediReach API/server code in this folder.

Recommended modules:
- Authentication
- Users
- Medical Shops
- Medicines
- Orders
- Delivery
- Prescription Upload
- Admin

Replace this placeholder with the actual backend code.
